red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
purple='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
yellow='\e[1;33m'
clear
echo -e $red
echo -e $red 1- $white TERMUX
echo ""
echo -e $red 2- $white  Gunroot$yellow AND$white KALI LINUX 
echo ""
echo -e $red 3- $yellow V$red P$green N
echo ""
echo -e $cyan
read -p "Enter The Number: " robot
if [ $robot = 1 ]
then
apt update -y
apt upgrade -y
pkg install python -y
pkg install python2 -y
pkg install python3 -y
pkg install figlet -y
pkg install php -y
bash ROBOT-ATTACK.sh
fi
if [ $robot = 2 ]
then
apt update -y
apt upgrade -y
apt-get install python -y
apt-get install python2 -y
apt-get install python3 -y
apt-get install figlet -y
bash ROBOT-ATTACK.sh
fi
if [ $robot = 3 ]
then 
pkg install tor -y
tor
fi
if [ $exit =  ]
then
bash install.sh
fi
