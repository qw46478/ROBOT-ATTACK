# Hunner
Hacking framework
This framework is designed to perform penetration testing.
Its functions:
1) Scan sql vulnerability
2) Scan xxs vulnerability
3) Dos sites
4) Brutforce Ftp
5) Brutforse SSh
6) Brutforse mail Accounts
# Donate BTC: 1K96gLXbmgRhE7DsU33HFBuvohDgei5Z22
